package sharwarko.regis.edu.magic_the_gathering_decks;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.List;

import Domain.Deck;
import service.DeckSvcCacheImpl;

public class ContactSvcCacheImplTest {

    @Test
    public void testCRUD() {
        DeckSvcCacheImpl svc = DeckSvcCacheImpl.getInstance();
        Deck deck = new Deck();
        String[] list = {"Lightning Bolt", "Wrath of God", "Maze of Ith", "Tundra"};
        deck.setName("Creature Lagoon");
        deck.setCards(list);

        List<Deck> lister =svc.retrieveAll();
        assertNotNull(lister);
        int intialsize = lister.size();

        //test create method
        deck = svc.create(deck);
        assertNotNull(deck);

        //test the retrieve method
        lister = svc.retrieveAll();
        int size = lister.size();
        assertEquals(intialsize +1, size);

        //test the update method
        deck.setName("Buckly");
        deck = svc.update(deck);
        assertNotNull(deck);
        assertEquals("Buckly", deck.getName());

        //test delete method
        deck = svc.delete(deck);
        assertNotNull(deck);
        lister = svc.retrieveAll();
        size = lister.size();
        assertEquals(intialsize, size);
    }

}
