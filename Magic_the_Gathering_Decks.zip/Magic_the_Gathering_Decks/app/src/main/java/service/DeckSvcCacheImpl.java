package service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import Domain.Deck;

public class DeckSvcCacheImpl implements IDeckSvc {
    private int nextId = 0;
    private List<Deck> decks = new LinkedList<Deck>();

    private DeckSvcCacheImpl(){
        initList();
        initiList2();
    }

    private void initList(){
        ArrayList list = new ArrayList();
        list.add("Counterspell");
        list.add("Boomerang");
        list.add("Timetwister");
        list.add("Time Walk");
        Deck deck = new Deck();
        deck.setName("Vesuvan Doppleganger");
        deck.setCards(list);
        decks.add(deck);
    }
    private void initiList2(){
        ArrayList list2 = new ArrayList();
        list2.add("Argivian Archeologist");
        list2.add("Disenchant");
        list2.add("Swords to Plowsheres");
        list2.add("Tundra");
        Deck deck2 = new Deck();
        deck2.setName("Serra Angel");
        deck2.setCards(list2);
        decks.add(deck2);
    }

    private static DeckSvcCacheImpl instance = new DeckSvcCacheImpl();

    public static DeckSvcCacheImpl getInstance(){
        return instance;
    }

    @Override
    public Deck create(Deck deck) {
        deck.setId(nextId++);
        decks.add(deck);
        return deck;
    }

    public List<Deck> retrieveAll() {
        return decks;
    }

    public Deck update(Deck deck) {
        int size = decks.size();
        for (int i = 0; i < size; i++) {
            if (decks.get(i).getId() == deck.getId()) {
                decks.set(i, deck);
                break;
            }
        }
        return deck;
    }

    public Deck delete(Deck deck) {
        int size = decks.size();
        for (int i = 0; i < size; i++) {
            if (decks.get(i).getId() == deck.getId()) {
                decks.remove(i);
                break;
            }

        }
        return deck;
    }
}
