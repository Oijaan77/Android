package service;

import java.util.List;

import Domain.Deck;

public interface IDeckSvc {

    public Deck create(Deck deck);
    public List<Deck> retrieveAll();
    public Deck update(Deck deck);
    public Deck delete(Deck deck);
}
