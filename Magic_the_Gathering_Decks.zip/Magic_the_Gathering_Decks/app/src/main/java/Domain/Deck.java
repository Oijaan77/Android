package Domain;

import java.io.Serializable;
import java.util.ArrayList;

public class Deck implements Serializable {
    private int id;
    private String name;
    private ArrayList cards;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList getCards() {
        return cards;
    }

    public void addCard(String card){
        cards.add(card);
    }

    public void setCards(ArrayList cards) {
        this.cards = cards;
    }

    @Override
    public String toString() {
        return name;
    }
}
