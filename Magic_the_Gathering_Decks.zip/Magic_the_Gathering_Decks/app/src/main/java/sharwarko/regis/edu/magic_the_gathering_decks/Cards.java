package sharwarko.regis.edu.magic_the_gathering_decks;

public class Cards {
    private int img;
    private String name;

    public Cards(int img, String name) {
        this.img = img;
        this.name = name;
    }

    public int getImg() {
        return img;
    }

    public String getName() {
        return name;
    }
}
