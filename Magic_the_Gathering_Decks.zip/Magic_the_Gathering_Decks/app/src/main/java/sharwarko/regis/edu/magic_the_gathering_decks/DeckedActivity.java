package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Domain.Deck;
import service.DeckSvcCacheImpl;
import service.IDeckSvc;

//Master Activity
public class DeckedActivity extends AppCompatActivity {

    //Deck list
    private ListView listDecks = null;
    //Import interface
    private IDeckSvc deckSvc = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decked);

        listDecks = (ListView) findViewById(R.id.listDecks);

        deckSvc = DeckSvcCacheImpl.getInstance();

        Button returnHome = (Button) findViewById(R.id.goBack);
        returnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setReturn();
            }
        });

        Button createDeck = (Button) findViewById(R.id.createDeck);
        createDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deckCreate();
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        final List<Deck> list = deckSvc.retrieveAll();
        //set list of decks
        ArrayAdapter adapter = new ArrayAdapter<Deck>(this, android.R.layout.simple_list_item_1, list);
        listDecks.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listDecks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(DeckedActivity.this, DetailActivity.class);
                intent.putExtra("Deck", list.get(position));
                startActivity(intent);
            }
        });
    }

    private void deckCreate() {
        Intent intent = new Intent(this, DetailActivity.class);
        startActivity(intent);
    }

    private void setReturn() {
        finish();
    }

}
