package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class DeckedActivity extends AppCompatActivity {

    private String[] deckArray = {"Sharuum EDH", "Zur EDH", "Caliphe EDH"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decked);
        Button returnHome = (Button) findViewById(R.id.goBack);
        returnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setReturn();
            }
        });
        Button createDeck = (Button) findViewById(R.id.createDeck);
        createDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deckCreate();
            }
        });
        ListView listDecks = (ListView) findViewById(R.id.listDecks);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, deckArray);
        listDecks.setAdapter(arrayAdapter);

    }

    private void deckCreate() {
        Intent intent = new Intent(this, DetailActivity.class);
        startActivity(intent);
    }

    private void setReturn() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }


}
