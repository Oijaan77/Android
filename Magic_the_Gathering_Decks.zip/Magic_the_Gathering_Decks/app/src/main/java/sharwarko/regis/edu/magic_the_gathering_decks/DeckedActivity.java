package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import Domain.Deck;
import service.DeckSvcCacheImpl;
import service.IDeckSvc;

//Master Activity
public class DeckedActivity extends AppCompatActivity {

    //Deck list
    private ListView listDecks = null;
    //Import interface
    private IDeckSvc deckSvc = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decked);

        listDecks = (ListView) findViewById(R.id.listDecks);

        deckSvc = DeckSvcCacheImpl.getInstance();

        Button createDeck = (Button) findViewById(R.id.createDeck);
        createDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deckCreate();
            }
        });

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

    }

    @Override
    protected void onResume() {
        super.onResume();
        final List<Deck> list = deckSvc.retrieveAll();
        //set list of decks
        ArrayAdapter adapter = new ArrayAdapter<Deck>(this, android.R.layout.simple_list_item_1, list);
        listDecks.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        listDecks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(DeckedActivity.this, DeckViewActivity.class);
                intent.putExtra("Deck", list.get(position));
                startActivity(intent);
            }
        });
    }

    private void deckCreate() {
        final List<Deck> nDeck = new List<Deck>() {
            @Override
            public int size() {
                return 0;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public boolean contains(@Nullable Object o) {
                return false;
            }

            @NonNull
            @Override
            public Iterator<Deck> iterator() {
                return null;
            }

            @NonNull
            @Override
            public Object[] toArray() {
                return new Object[0];
            }

            @NonNull
            @Override
            public <T> T[] toArray(@NonNull T[] a) {
                return null;
            }

            @Override
            public boolean add(Deck deck) {
                return false;
            }

            @Override
            public boolean remove(@Nullable Object o) {
                return false;
            }

            @Override
            public boolean containsAll(@NonNull Collection<?> c) {
                return false;
            }

            @Override
            public boolean addAll(@NonNull Collection<? extends Deck> c) {
                return false;
            }

            @Override
            public boolean addAll(int index, @NonNull Collection<? extends Deck> c) {
                return false;
            }

            @Override
            public boolean removeAll(@NonNull Collection<?> c) {
                return false;
            }

            @Override
            public boolean retainAll(@NonNull Collection<?> c) {
                return false;
            }

            @Override
            public void clear() {

            }

            @Override
            public Deck get(int index) {
                return null;
            }

            @Override
            public Deck set(int index, Deck element) {
                return null;
            }

            @Override
            public void add(int index, Deck element) {

            }

            @Override
            public Deck remove(int index) {
                return null;
            }

            @Override
            public int indexOf(@Nullable Object o) {
                return 0;
            }

            @Override
            public int lastIndexOf(@Nullable Object o) {
                return 0;
            }

            @NonNull
            @Override
            public ListIterator<Deck> listIterator() {
                return null;
            }

            @NonNull
            @Override
            public ListIterator<Deck> listIterator(int index) {
                return null;
            }

            @NonNull
            @Override
            public List<Deck> subList(int fromIndex, int toIndex) {
                return null;
            }
        };
        Intent intent = new Intent(this, DetailActivity.class);
        startActivity(intent);
    }

}
