package sharwarko.regis.edu.magic_the_gathering_decks;

public class Decks {
    private int myImage;
    private String deckTitle;

    public Decks(int myImage, String deckTitle) {
        this.deckTitle = deckTitle;
    }

    public int getMyImage() {
        return myImage;
    }

    public String getDeckTitle() {
        return deckTitle;
    }
}
