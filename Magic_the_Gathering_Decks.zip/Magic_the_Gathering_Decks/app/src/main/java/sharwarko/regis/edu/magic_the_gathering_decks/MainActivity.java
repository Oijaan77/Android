package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private final String TAG = "MainActivity";
    private Button deckLink;
    private Button aboutLink;
    private Button contactLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG, "Entering OnCreate");
        deckLink = (Button) findViewById(R.id.deckLink);
        deckLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDeckLink();
            }
        });
        aboutLink = (Button) findViewById(R.id.aboutLink);
        aboutLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAbout();
            }
        });
        contactLink = (Button) findViewById(R.id.contactLink);
        contactLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setContact();
            }
        });
    }

    private void setContact() {
        Intent intent = new Intent(this, ContactUsActivity.class);
        startActivity(intent);
    }

    private void setAbout() {
        Intent intent = new Intent(this, AboutUsActivity.class);
        startActivity(intent);
    }

    private void setDeckLink() {
        Intent intent = new Intent(this, DeckedActivity.class);
        startActivity(intent);
    }
}
