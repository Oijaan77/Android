package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.logging.FileHandler;

import Domain.Deck;
import service.DeckSvcCacheImpl;
import service.IDeckSvc;

public class DetailActivity extends AppCompatActivity {
    //deck object
    private Deck deck;
    //access interface
    private IDeckSvc deckSvc;
    //add/find cards text
    private EditText fCards;
    //deck name
    private EditText dText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        deckSvc = DeckSvcCacheImpl.getInstance();

        //back btn
        Button goBack = (Button) findViewById(R.id.goBack);
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backCancel(v);
            }
        });

        fCards = findViewById(R.id.findCards);
        dText = findViewById(R.id.deckName);

        Button addCard = findViewById(R.id.addCard);
        addCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCard(v);
            }
        });

        Button addDeck = findViewById(R.id.addDeck);
        addDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDeck(v);
            }
        });
        ListView listCard = findViewById(R.id.listCard);

        //Display list of cards from current deck
        deck = (Deck) getIntent().getSerializableExtra("Deck");
        if (deck != null){
            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, deck.getCards());
            listCard.setAdapter(adapter);
            dText.setText(deck.getName());
        }

    }
    //method to add card to deck
    private void saveCard(View v) {
        deck = (Deck) getIntent().getSerializableExtra("Deck");
        deck.addCard(fCards.getText().toString());
        deckSvc.update(deck);
        Toast.makeText(this, "Card Added to Deck", Toast.LENGTH_SHORT).show();
    }

    private void backCancel(View view) {
        finish();
    }

    //method to save deck
    public void saveDeck(View view) {
        deck = new Deck();
        deck.setName(dText.getText().toString());
        deckSvc.update(deck);
        Toast.makeText(this, "Deck has been saved", Toast.LENGTH_SHORT).show();
        finish();
    }

}
