package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.logging.FileHandler;

import Domain.Deck;
import service.DeckSvcCacheImpl;
import service.IDeckSvc;

public class DetailActivity extends AppCompatActivity {
    //deck object
    private Deck deck;
    //access interface
    private IDeckSvc deckSvc;
    //add/find cards text
    private EditText fCards;
    //deck name
    private EditText dText;
    //card title
    private TextView textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);


        deckSvc = DeckSvcCacheImpl.getInstance();

        fCards = findViewById(R.id.findCards);
        dText = findViewById(R.id.deckName);
        textView3 = findViewById(R.id.textView3);

        Button addCard = findViewById(R.id.addCard);
        addCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCard(v);
            }
        });

        Button addDeck = findViewById(R.id.addDeck);
        addDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveDeck(v);
            }
        });
        ListView listCard = findViewById(R.id.listCard);

        //Display list of cards from current deck
        deck = (Deck) getIntent().getSerializableExtra("Deck");
        if (deck != null){
            addDeck.setText("Update");
            if(deck.getCards() != null){
                ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, deck.getCards());
                listCard.setAdapter(adapter);
            }
            dText.setText(deck.getName());
        } else {
            addCard.setVisibility(View.INVISIBLE);
            fCards.setVisibility(View.INVISIBLE);
            textView3.setVisibility(View.INVISIBLE);
            dText.setHint("Enter a Deck Name");
        }

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

    }
    //method to add card to deck
    private void saveCard(View v) {
        deck = (Deck) getIntent().getSerializableExtra("Deck");
        if (deck != null) {
            deck.addCard(fCards.getText().toString());
            fCards.setText("");
            deckSvc.update(deck);
            Toast.makeText(this, "Card Added to Deck", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please save a deck first", Toast.LENGTH_SHORT).show();
        }

    }

    //method to save deck
    public void saveDeck(View view) {
        if (deck != null){
            Toast.makeText(this, "Deck has been Updated", Toast.LENGTH_SHORT).show();
        } else {
            Deck newDeck = new Deck();
            ArrayList list = new ArrayList();
            newDeck.setName(dText.getText().toString());
            list.add("");
            newDeck.setCards(list);
            deckSvc.create(newDeck);
            Toast.makeText(this, "Deck has been Created", Toast.LENGTH_SHORT).show();
        }
        Intent intent = new Intent(this, DeckedActivity.class);
        startActivity(intent);
    }

}
