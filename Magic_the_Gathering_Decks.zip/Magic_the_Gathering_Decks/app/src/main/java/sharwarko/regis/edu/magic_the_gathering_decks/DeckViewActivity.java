package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import Domain.Deck;
import service.DeckSvcCacheImpl;
import service.IDeckSvc;

public class DeckViewActivity extends AppCompatActivity {

    private ListView listCard = null;
    //deck object
    private Deck deck;
    //access interface
    private IDeckSvc deckSvc;
    //deck name
    private TextView dText;
    private Button editDeck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deck_view);

        deckSvc = DeckSvcCacheImpl.getInstance();

        dText = findViewById(R.id.nameDeck);

        Button editDeck = findViewById(R.id.editDeck);
        editDeck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit();
            }
        });

       listCard = (ListView) findViewById(R.id.deckLister);

        //Display list of cards from current deck
        deck = (Deck) getIntent().getSerializableExtra("Deck");
        if (deck != null){
            if(deck.getCards() != null){
                ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, deck.getCards());
                listCard.setAdapter(adapter);
            }

            dText.setText(deck.getName());
        }

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

    }
    private void edit() {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("Deck", this.deck);
        startActivity(intent);

    }
}


