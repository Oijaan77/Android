package sharwarko.regis.edu.magic_the_gathering_decks;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DeckViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deck_view);
    }
}
